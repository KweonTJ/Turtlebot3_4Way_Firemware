/*******************************************************************************
* Copyright 2016 ROBOTIS CO., LTD.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*******************************************************************************/

/* Authors: Yoonseok Pyo, Leon Jung, Darby Lim, HanCheol Cho */

#include "turtlebot3_motor_driver.h"

Turtlebot3MotorDriver::Turtlebot3MotorDriver()
: baudrate_(BAUDRATE),
  protocol_version_(PROTOCOL_VERSION),
  left_wheel_id_(DXL_LEFT_ID),
  right_wheel_id_(DXL_RIGHT_ID)
{
  torque_ = false;
  dynamixel_limit_max_velocity_ = BURGER_DXL_LIMIT_MAX_VELOCITY;
}

Turtlebot3MotorDriver::~Turtlebot3MotorDriver()
{
  close();
}

bool Turtlebot3MotorDriver::init(String turtlebot3)
{
  DEBUG_SERIAL.begin(57600);
  portHandler_   = dynamixel::PortHandler::getPortHandler(DEVICENAME);
  packetHandler_ = dynamixel::PacketHandler::getPacketHandler(PROTOCOL_VERSION);

  // Open port
  if (portHandler_->openPort() == false)
  {
    DEBUG_SERIAL.println("Failed to open port(Motor Driver)");
    return false;
  }

  // Set port baudrate
  if (portHandler_->setBaudRate(baudrate_) == false)
  {
    DEBUG_SERIAL.println("Failed to set baud rate(Motor Driver)");
    return false;
  }

  // ================== [ 핵심 수정 부분 1: ID 배열 초기화 및 모터 설정 ] ==================
  // 4개의 모터 ID를 dxl_id_ 배열에 저장합니다.
  dxl_id_[0] = DXL_LEFT_REAR_ID;
  dxl_id_[1] = DXL_RIGHT_REAR_ID;
  dxl_id_[2] = DXL_LEFT_FRONT_ID;
  dxl_id_[3] = DXL_RIGHT_FRONT_ID;

  // for 루프를 사용하여 4개의 모터에 대해 ping 테스트와 휠 모드 설정을 반복합니다.
  for (int i = 0; i < 4; i++)
  {
    uint16_t model_number = 0;
    // ping으로 모터가 연결되었는지 확인
    if (packetHandler_->ping(portHandler_, dxl_id_[i], &model_number) != COMM_SUCCESS) return false;
    // 휠 모드(무한 회전)로 설정 (Control Table Address 11, Value 1)
    if (packetHandler_->write1ByteTxRx(portHandler_, dxl_id_[i], 11, 1, NULL) != COMM_SUCCESS) return false;
  }
  // ===================================================================================


  groupSyncWriteVelocity_ = new dynamixel::GroupSyncWrite(portHandler_, packetHandler_, ADDR_X_GOAL_VELOCITY, LEN_X_GOAL_VELOCITY);
  groupSyncReadEncoder_   = new dynamixel::GroupSyncRead(portHandler_, packetHandler_, ADDR_X_PRESENT_POSITION, LEN_X_PRESENT_POSITION);
  
  if (turtlebot3 == "Burger")
    dynamixel_limit_max_velocity_ = BURGER_DXL_LIMIT_MAX_VELOCITY;
  else if (turtlebot3 == "Waffle or Waffle Pi")
    dynamixel_limit_max_velocity_ = WAFFLE_DXL_LIMIT_MAX_VELOCITY;
  else
    dynamixel_limit_max_velocity_ = BURGER_DXL_LIMIT_MAX_VELOCITY;

  DEBUG_SERIAL.println("Success to init Motor Driver");

  setTorque(true);
  return true;
}

bool Turtlebot3MotorDriver::setTorque(bool onoff)
{
  uint8_t dxl_error = 0;
  int dxl_comm_result = COMM_TX_FAIL;

  torque_ = onoff;
  // ================== [ 핵심 수정 부분 2: 토크 설정 ] ==================
  // for 루프를 사용하여 4개 모터의 토크를 한 번에 켜거나 끕니다.
  for (int i = 0; i < 4; i++)
  {
    if (packetHandler_->write1ByteTxRx(portHandler_, dxl_id_[i], ADDR_X_TORQUE_ENABLE, onoff, NULL) != COMM_SUCCESS)
      return false;
  }
  return true;
  // ====================================================================

  dxl_comm_result = packetHandler_->write1ByteTxRx(portHandler_, DXL_LEFT_ID, ADDR_X_TORQUE_ENABLE, onoff, &dxl_error);
  if(dxl_comm_result != COMM_SUCCESS)
  {
    Serial.println(packetHandler_->getTxRxResult(dxl_comm_result));
    return false;
  }
  else if(dxl_error != 0)
  {
    Serial.println(packetHandler_->getRxPacketError(dxl_error));
    return false;
  }

  dxl_comm_result = packetHandler_->write1ByteTxRx(portHandler_, DXL_RIGHT_ID, ADDR_X_TORQUE_ENABLE, onoff, &dxl_error);
  if(dxl_comm_result != COMM_SUCCESS)
  {
    Serial.println(packetHandler_->getTxRxResult(dxl_comm_result));
    return false;
  }
  else if(dxl_error != 0)
  {
    Serial.println(packetHandler_->getRxPacketError(dxl_error));
    return false;
  }

  return true;
}

bool Turtlebot3MotorDriver::getTorque()
{
  return torque_;
}

void Turtlebot3MotorDriver::close(void)
{
  // Disable Dynamixel Torque
  setTorque(false);

  // Close port
  portHandler_->closePort();
  DEBUG_SERIAL.end();
}

// bool Turtlebot3MotorDriver::readEncoder(int32_t &left_value, int32_t &right_value)
bool Turtlebot3MotorDriver::readEncoder(int32_t* value)
{
  // int dxl_comm_result = COMM_TX_FAIL;              // Communication result
  // bool dxl_addparam_result = false;                // addParam result
  // bool dxl_getdata_result = false;                 // GetParam result

  // // Set parameter
  // dxl_addparam_result = groupSyncReadEncoder_->addParam(left_wheel_id_);
  // if (dxl_addparam_result != true)
  //   return false;

  // dxl_addparam_result = groupSyncReadEncoder_->addParam(right_wheel_id_);
  // if (dxl_addparam_result != true)
  //   return false;

  // // Syncread present position
  // dxl_comm_result = groupSyncReadEncoder_->txRxPacket();
  // if (dxl_comm_result != COMM_SUCCESS)
  //   Serial.println(packetHandler_->getTxRxResult(dxl_comm_result));

  // // Check if groupSyncRead data of Dynamixels are available
  // dxl_getdata_result = groupSyncReadEncoder_->isAvailable(left_wheel_id_, ADDR_X_PRESENT_POSITION, LEN_X_PRESENT_POSITION);
  // if (dxl_getdata_result != true)
  //   return false;

  // dxl_getdata_result = groupSyncReadEncoder_->isAvailable(right_wheel_id_, ADDR_X_PRESENT_POSITION, LEN_X_PRESENT_POSITION);
  // if (dxl_getdata_result != true)
  //   return false;

  // // Get data
  // left_value  = groupSyncReadEncoder_->getData(left_wheel_id_,  ADDR_X_PRESENT_POSITION, LEN_X_PRESENT_POSITION);
  // right_value = groupSyncReadEncoder_->getData(right_wheel_id_, ADDR_X_PRESENT_POSITION, LEN_X_PRESENT_POSITION);

  // groupSyncReadEncoder_->clearParam();
  groupSyncReadEncoder_->clearParam();
  // for 루프를 사용하여 4개 모터의 엔코더 값을 읽도록 요청 리스트에 추가합니다.
  for (int i = 0; i < 4; i++)
  {
    if (groupSyncReadSEncoder_->addParam(dxl_id_[i]) != true) return false;
  }

  // 한 번의 통신으로 4개 모터의 엔코더 값을 모두 읽어옵니다.
  if (groupSyncReadEncoder_->txRxPacket() != COMM_SUCCESS) return false;

  // for 루프를 사용하여 읽어온 데이터를 value 배열에 순서대로 저장합니다.
  for (int i = 0; i < 4; i++)
  {
    // 각 모터의 데이터가 수신되었는지 확인
    if (groupSyncReadEncoder_->isAvailable(dxl_id_[i], ADDR_X_PRESENT_POSITION, LEN_X_PRESENT_POSITION))
    {
      value[i] = groupSyncReadEncoder_->getData(dxl_id_[i], ADDR_X_PRESENT_POSITION, LEN_X_PRESENT_POSITION);
    }
  }
  return true;
}

// bool Turtlebot3MotorDriver::writeVelocity(int64_t left_value, int64_t right_value)
// {
//   bool dxl_addparam_result;
//   int8_t dxl_comm_result;

//   uint8_t left_data_byte[4] = {0, };
//   uint8_t right_data_byte[4] = {0, };


//   left_data_byte[0] = DXL_LOBYTE(DXL_LOWORD(left_value));
//   left_data_byte[1] = DXL_HIBYTE(DXL_LOWORD(left_value));
//   left_data_byte[2] = DXL_LOBYTE(DXL_HIWORD(left_value));
//   left_data_byte[3] = DXL_HIBYTE(DXL_HIWORD(left_value));

//   dxl_addparam_result = groupSyncWriteVelocity_->addParam(left_wheel_id_, (uint8_t*)&left_data_byte);
//   if (dxl_addparam_result != true)
//     return false;

//   right_data_byte[0] = DXL_LOBYTE(DXL_LOWORD(right_value));
//   right_data_byte[1] = DXL_HIBYTE(DXL_LOWORD(right_value));
//   right_data_byte[2] = DXL_LOBYTE(DXL_HIWORD(right_value));
//   right_data_byte[3] = DXL_HIBYTE(DXL_HIWORD(right_value));

//   dxl_addparam_result = groupSyncWriteVelocity_->addParam(right_wheel_id_, (uint8_t*)&right_data_byte);
//   if (dxl_addparam_result != true)
//     return false;

//   dxl_comm_result = groupSyncWriteVelocity_->txPacket();
//   if (dxl_comm_result != COMM_SUCCESS)
//   {
//     Serial.println(packetHandler_->getTxRxResult(dxl_comm_result));
//     return false;
//   }

//   groupSyncWriteVelocity_->clearParam();
//   return true;
// }

bool Turtlebot3MotorDriver::controlMotor(const float wheel_radius, const float wheel_separation, float* value)
{
  // bool dxl_comm_result = false;
  // float wheel_velocity_cmd[2];

  float lin_vel = value[LINEAR];
  float ang_vel = value[ANGULAR];

  // wheel_velocity_cmd[LEFT]   = lin_vel - (ang_vel * wheel_separation / 2);
  // wheel_velocity_cmd[RIGHT]  = lin_vel + (ang_vel * wheel_separation / 2);

  // wheel_velocity_cmd[LEFT]  = constrain(wheel_velocity_cmd[LEFT]  * VELOCITY_CONSTANT_VALUE / wheel_radius, -dynamixel_limit_max_velocity_, dynamixel_limit_max_velocity_);
  // wheel_velocity_cmd[RIGHT] = constrain(wheel_velocity_cmd[RIGHT] * VELOCITY_CONSTANT_VALUE / wheel_radius, -dynamixel_limit_max_velocity_, dynamixel_limit_max_velocity_);

  // dxl_comm_result = writeVelocity((int64_t)wheel_velocity_cmd[LEFT], (int64_t)wheel_velocity_cmd[RIGHT]);
  // if (dxl_comm_result == false)
  //   return false;
  // 4륜 스키드 스티어(Skid-steer) 운동학(Kinematics) 계산
  // 로봇의 선속도와 각속도를 기반으로 왼쪽 바퀴들과 오른쪽 바퀴들의 목표 속도를 계산합니다.
  double left_wheel_vel  = lin_vel - (ang_vel * wheel_separation / 2.0);
  double right_wheel_vel = lin_vel + (ang_vel * wheel_separation / 2.0);

  // 속도(m/s)를 다이나믹셀 RPM 단위 값(정수)으로 변환합니다.
  // 기존 VELOCITY_CONSTANT_VALUE와 wheel_radius를 이용한 계산을 명시적으로 풀어쓴 것입니다.
  double rpm = 1.0 / (wheel_radius * 0.10472); // 0.10472 = 2*PI/60
  double velocity_to_dxl_rpm_unit = rpm * 0.229;
  int32_t dxl_left_vel_cmd  = left_wheel_vel * VELOCITY_CONSTANT_VALUE / wheel_radius;
  int32_t dxl_right_vel_cmd = right_wheel_vel * VELOCITY_CONSTANT_VALUE / wheel_radius;

  // 속도 제한 (constrain)
  dxl_left_vel_cmd  = constrain(dxl_left_vel_cmd, -dynamixel_limit_max_velocity_, dynamixel_limit_max_velocity_);
  dxl_right_vel_cmd = constrain(dxl_right_vel_cmd, -dynamixel_limit_max_velocity_, dynamixel_limit_max_velocity_);

  groupSyncWriteVelocity_->clearParam();
  
  // 4개 모터에 속도 명령을 추가합니다. 왼쪽 바퀴 2개는 같은 속도, 오른쪽 바퀴 2개는 같은 속도를 가집니다.
  groupSyncWriteVelocity_->addParam(dxl_id_[0], (uint8_t*)&dxl_left_vel_cmd);  // LEFT_REAR
  groupSyncWriteVelocity_->addParam(dxl_id_[1], (uint8_t*)&dxl_right_vel_cmd); // RIGHT_REAR
  groupSyncWriteVelocity_->addParam(dxl_id_[2], (uint8_t*)&dxl_left_vel_cmd);  // LEFT_FRONT
  groupSyncWriteVelocity_->addParam(dxl_id_[3], (uint8_t*)&dxl_right_vel_cmd); // RIGHT_FRONT

  // 한 번의 통신으로 4개 모터에 동시에 속도 명령을 전송합니다.
  if (groupSyncWriteVelocity_->txPacket() != COMM_SUCCESS) return false;

  return true;
}
